function abrirPagina() {
    window.location.href = 'mario.html';
}
function abrirPagina2() {
    window.location.href = 'sonic.html';
}
function abrirPagina3() {
    window.location.href = 'donkeykong.html';
}
function abrirPagina4() {
    window.location.href = 'megamanx.html';
}
function abrirPagina5() {
    window.location.href = 'index.html';
}